import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-popover-tooltip',
  templateUrl: './popover-tooltip.component.html'
})
export class PopoverTooltipComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
