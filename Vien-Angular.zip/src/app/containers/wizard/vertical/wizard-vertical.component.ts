import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wizard-vertical',
  templateUrl: './wizard-vertical.component.html'
})
export class WizardVerticalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
