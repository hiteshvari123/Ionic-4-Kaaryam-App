export interface ITicket {
    title: string;
    detail: string;
    thumb: string;
}

const data: ITicket[] = [
    {
        title: 'Mayra Sibley',
        detail: '09.08.2018 - 12:45',
        thumb: '/assets/img/profile-pic-l.jpg'
    },
    {
        title: 'Mimi Carreira',
        detail: '05.08.2018 - 10:20',
        thumb: '/assets/img/profile-pic-l-2.jpg'
    },
    {
        title: 'Philip Nelms',
        detail: '05.08.2018 - 09:12',
        thumb: '/assets/img/profile-pic-l-3.jpg'
    },
    {
        title: 'Terese Threadgill',
        detail: '01.08.2018 - 18:20',
        thumb: '/assets/img/profile-pic-l-4.jpg'
    },
    {
        title: 'Kathryn Mengel',
        detail: '27.07.2018 - 11:45',
        thumb: '/assets/img/profile-pic-l-5.jpg'
    },
    {
        title: 'Esperanza Lodge',
        detail: '24.07.2018 - 15:00',
        thumb: '/assets/img/profile-pic-l-2.jpg'
    },
    {
        title: 'Laree Munsch',
        detail: '24.05.2018 - 11:00',
        thumb: '/assets/img/profile-pic-l.jpg'
    }
];

export default data;
