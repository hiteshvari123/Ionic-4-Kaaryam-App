import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mailing',
  templateUrl: './mailing.component.html'
})
export class MailingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
