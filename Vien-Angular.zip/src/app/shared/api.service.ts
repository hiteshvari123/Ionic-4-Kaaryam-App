import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpRequest } from "@angular/common/http";
import { map } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class ApiService {

  BASE_URL="https://www.dheya.com/MyClapAPI/api/";
  apitoken='apitoken:MyClapDheya@2017:DheyaApi@20177';


  constructor(private http:HttpClient) {
    console.log("Api service provider.....");
   }


   login(param){
    const httpHeaders = new HttpHeaders({
      'AuthToken': 'MyClapDheya@2017:DheyaApi@2017',
      'Content-Type': 'application/json',
      'Accept':'application/json'
    });
    const options = {
        headers: httpHeaders
    };
     return this.http.post(this.BASE_URL+"userLogin",param,options);
   }

}