import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-badges',
  templateUrl: './badges.component.html'
})
export class BadgesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
