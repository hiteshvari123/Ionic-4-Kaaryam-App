import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modal-directive',
  templateUrl: './modal-directive.component.html'
})
export class ModalDirectiveComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
