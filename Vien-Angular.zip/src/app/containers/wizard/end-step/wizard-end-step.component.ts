import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wizard-end-step',
  templateUrl: './wizard-end-step.component.html'
})
export class WizardEndStepComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
