import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-validations',
  templateUrl: './validations.component.html'
})
export class ValidationsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
