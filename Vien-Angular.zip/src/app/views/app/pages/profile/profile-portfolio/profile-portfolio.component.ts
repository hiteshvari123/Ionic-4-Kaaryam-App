import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-portfolio',
  templateUrl: './profile-portfolio.component.html'
})
export class ProfilePortfolioComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
