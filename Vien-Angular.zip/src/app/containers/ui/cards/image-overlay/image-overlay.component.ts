import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-image-overlay',
  templateUrl: './image-overlay.component.html'
})
export class ImageOverlayComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
