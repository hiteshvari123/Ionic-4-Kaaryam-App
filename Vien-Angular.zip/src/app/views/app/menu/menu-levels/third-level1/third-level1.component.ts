import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-third-level1',
  templateUrl: './third-level1.component.html'
})
export class ThirdLevel1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
